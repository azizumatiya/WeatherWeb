function reload(){
    
    if(confirm("Are you sure, You want to Refresh??")){
        location.reload();
    }
}
function Refresh(){
    
    {
        location.reload();
    }
}
